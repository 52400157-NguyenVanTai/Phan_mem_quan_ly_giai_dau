﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GUI.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            if (Session["UserId"] != null)
            {
                return RedirectToAction("Index", "Dashboard");
            }

            return View();
        }

        public ActionResult DangNhap()
        {
            if (Session["UserId"] != null)
            {
                return RedirectToAction("Index", "Dashboard");
            }

            return View();
        }

        public ActionResult DangKy()
        {
            if (Session["UserId"] != null)
            {
                return RedirectToAction("Index", "Dashboard");
            }

            return View();
        }

        public ActionResult QuenMatKhau()
        {
            if (Session["UserId"] != null)
            {
                return RedirectToAction("Index", "Dashboard");
            }

            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}