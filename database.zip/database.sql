-- ================================================================
-- QUANLY_ESPORTS — DATABASE_MAIN COMPLETE RESET SCRIPT
-- Version : main-1.0 (Drop if exists + Create full schema)
-- Engine  : SQL Server 2019+
-- Encoding: UTF-8 / NVARCHAR throughout
-- ================================================================
-- HOW TO USE:
--   1. Chay bang SQL Server Management Studio hoac Visual Studio SQL editor
--   2. Script se xoa database QuanLy_Esports neu da ton tai
--   3. Script tao lai database QuanLy_Esports va toan bo schema tu dau
--   4. Tat ca du lieu cu trong database QuanLy_Esports se bi xoa
-- ==============================================================

USE master;
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;
GO

IF DB_ID(N'QuanLy_Esports') IS NOT NULL
BEGIN
    ALTER DATABASE QuanLy_Esports SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE QuanLy_Esports;
END
GO

CREATE DATABASE QuanLy_Esports COLLATE Vietnamese_CI_AS;
GO

USE QuanLy_Esports;
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;
GO

-- ================================================================
-- THONG KE HE THONG DATABASE
-- ================================================================
-- Nhom danh muc: TRO_CHOI, DANH_MUC_VI_TRI
-- Nhom nguoi dung: NGUOI_DUNG, HO_SO_IN_GAME
-- Nhom doi tuyen: DOI, NHOM_DOI, THANH_VIEN_DOI
-- Nhom tuyen dung: BAI_DANG_TUYEN_DUNG, DON_UNG_TUYEN, LOI_MOI_GIA_NHAP, XIN_GIA_NHAP, YEU_CAU_THAM_GIA_NHOM, YEU_CAU_XAC_NHAN_LOI_MOI
-- Nhom giai dau: GIAI_DAU, QUAN_TRI_GIAI_DAU, YEU_CAU_TAO_GIAI_DAU, THAM_GIA_GIAI, DOI_HINH_THI_DAU, GIAI_THUONG, GIAI_DOAN
-- Nhom tran dau/ket qua: TRAN_DAU, CHI_TIET_TRAN_DAU, KET_QUA_TRAN, LICH_SU_SUA_KET_QUA, KHIEU_NAI_KET_QUA, YEU_CAU_MO_KHOA_KET_QUA
-- Nhom thong ke: CHI_TIET_NGUOI_CHOI_TRAN, BANG_XEP_HANG, BANG_XEP_HANG_CA_NHAN
-- Nhom thong bao/tuong tac: THONG_BAO, TUONG_TAC_GIAI_DAU
-- Nhom trong tai: DANG_KY_TRONG_TAI
-- Views: VW_DASHBOARD_STATS, VW_TUONG_TAC_TONG_HOP

-- ==============================================================
-- SECTION 1 — LOOKUP / MASTER DATA
-- ==============================================================

-- ---------------------------------------------------------------
-- 1.1  TRO_CHOI  (Game catalogue — chỉ 6 tựa game được phép)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'TRO_CHOI')
BEGIN
    CREATE TABLE TRO_CHOI (
        ma_tro_choi  INT          IDENTITY PRIMARY KEY,
        ten_game     NVARCHAR(100) NOT NULL,
        the_loai     NVARCHAR(50)  NOT NULL,   -- MOBA | FPS | BATTLEROYALE
        is_active    BIT           NOT NULL CONSTRAINT DF_TC_ACTIVE   DEFAULT 1,

        CONSTRAINT UQ_TC_TEN_GAME CHECK (ten_game IN (
            N'Arena of Valor',
            N'League of Legends',
            N'Free Fire',
            N'PUBG',
            N'Valorant',
            N'CS:GO'
        )),
        CONSTRAINT CHK_TC_THE_LOAI CHECK (the_loai IN ('MOBA','FPS','BATTLEROYALE'))
    );
END
GO

-- ---------------------------------------------------------------
-- 1.2  DANH_MUC_VI_TRI  (Position master data)
--
-- loai_vi_tri = 'TuyenThu'  → vị trí thi đấu theo game
-- loai_vi_tri = 'HuanLuyen'→ HLV, Chiến thuật, Trợ lí, Quản lý
--               không ràng buộc theo game (ma_tro_choi = NULL)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'DANH_MUC_VI_TRI')
BEGIN
    CREATE TABLE DANH_MUC_VI_TRI (
        ma_vi_tri    INT          IDENTITY PRIMARY KEY,
        ma_tro_choi  INT          NULL,          -- NULL → áp dụng cho ban huấn luyện
        ten_vi_tri   NVARCHAR(100) NOT NULL,
        ky_hieu      NVARCHAR(20)  NOT NULL,
        loai_vi_tri  NVARCHAR(20)  NOT NULL,

        CONSTRAINT CHK_VITRI_LOAI CHECK (loai_vi_tri IN ('TuyenThu','HuanLuyen')),
        CONSTRAINT FK_VITRI_GAME  FOREIGN KEY (ma_tro_choi) REFERENCES TRO_CHOI(ma_tro_choi)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM TRO_CHOI WHERE ten_game = N'Arena of Valor')
    INSERT INTO TRO_CHOI (ten_game, the_loai) VALUES (N'Arena of Valor', 'MOBA');
IF NOT EXISTS (SELECT 1 FROM TRO_CHOI WHERE ten_game = N'League of Legends')
    INSERT INTO TRO_CHOI (ten_game, the_loai) VALUES (N'League of Legends', 'MOBA');
IF NOT EXISTS (SELECT 1 FROM TRO_CHOI WHERE ten_game = N'Free Fire')
    INSERT INTO TRO_CHOI (ten_game, the_loai) VALUES (N'Free Fire', 'BATTLEROYALE');
IF NOT EXISTS (SELECT 1 FROM TRO_CHOI WHERE ten_game = N'PUBG')
    INSERT INTO TRO_CHOI (ten_game, the_loai) VALUES (N'PUBG', 'BATTLEROYALE');
IF NOT EXISTS (SELECT 1 FROM TRO_CHOI WHERE ten_game = N'Valorant')
    INSERT INTO TRO_CHOI (ten_game, the_loai) VALUES (N'Valorant', 'FPS');
IF NOT EXISTS (SELECT 1 FROM TRO_CHOI WHERE ten_game = N'CS:GO')
    INSERT INTO TRO_CHOI (ten_game, the_loai) VALUES (N'CS:GO', 'FPS');
GO

DECLARE @AOV INT = (SELECT ma_tro_choi FROM TRO_CHOI WHERE ten_game = N'Arena of Valor');
DECLARE @LOL INT = (SELECT ma_tro_choi FROM TRO_CHOI WHERE ten_game = N'League of Legends');
DECLARE @FREEFIRE INT = (SELECT ma_tro_choi FROM TRO_CHOI WHERE ten_game = N'Free Fire');
DECLARE @PUBG INT = (SELECT ma_tro_choi FROM TRO_CHOI WHERE ten_game = N'PUBG');
DECLARE @VALORANT INT = (SELECT ma_tro_choi FROM TRO_CHOI WHERE ten_game = N'Valorant');
DECLARE @CSGO INT = (SELECT ma_tro_choi FROM TRO_CHOI WHERE ten_game = N'CS:GO');

IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @AOV AND ky_hieu = N'DS')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@AOV, N'Đường Caesar', N'DS', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @AOV AND ky_hieu = N'JG')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@AOV, N'Đi rừng', N'JG', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @AOV AND ky_hieu = N'MID')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@AOV, N'Đường giữa', N'MID', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @AOV AND ky_hieu = N'AD')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@AOV, N'Xạ thủ', N'AD', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @AOV AND ky_hieu = N'SP')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@AOV, N'Trợ thủ', N'SP', 'TuyenThu');

IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @LOL AND ky_hieu = N'TOP')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@LOL, N'Đường trên', N'TOP', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @LOL AND ky_hieu = N'JGL')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@LOL, N'Đi rừng', N'JGL', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @LOL AND ky_hieu = N'MID')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@LOL, N'Đường giữa', N'MID', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @LOL AND ky_hieu = N'ADC')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@LOL, N'Xạ thủ', N'ADC', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @LOL AND ky_hieu = N'SUP')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@LOL, N'Hỗ trợ', N'SUP', 'TuyenThu');

IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @VALORANT AND ky_hieu = N'DUEL')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@VALORANT, N'Duelist', N'DUEL', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @VALORANT AND ky_hieu = N'INIT')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@VALORANT, N'Initiator', N'INIT', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @VALORANT AND ky_hieu = N'CTRL')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@VALORANT, N'Controller', N'CTRL', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @VALORANT AND ky_hieu = N'SENT')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@VALORANT, N'Sentinel', N'SENT', 'TuyenThu');

IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @CSGO AND ky_hieu = N'ENTRY')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@CSGO, N'Entry Fragger', N'ENTRY', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @CSGO AND ky_hieu = N'AWP')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@CSGO, N'AWPer', N'AWP', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @CSGO AND ky_hieu = N'IGL')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@CSGO, N'In-game Leader', N'IGL', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @CSGO AND ky_hieu = N'SUP')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@CSGO, N'Support', N'SUP', 'TuyenThu');

IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @FREEFIRE AND ky_hieu = N'RUSH')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@FREEFIRE, N'Rusher', N'RUSH', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @FREEFIRE AND ky_hieu = N'SNIPER')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@FREEFIRE, N'Sniper', N'SNIPER', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @FREEFIRE AND ky_hieu = N'SUPPORT')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@FREEFIRE, N'Support', N'SUPPORT', 'TuyenThu');

IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @PUBG AND ky_hieu = N'IGL')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@PUBG, N'Chỉ huy', N'IGL', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @PUBG AND ky_hieu = N'SCOUT')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@PUBG, N'Trinh sát', N'SCOUT', 'TuyenThu');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi = @PUBG AND ky_hieu = N'FRAG')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (@PUBG, N'Tấn công', N'FRAG', 'TuyenThu');

IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi IS NULL AND ky_hieu = N'HLV')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (NULL, N'Huấn luyện viên', N'HLV', 'HuanLuyen');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi IS NULL AND ky_hieu = N'PT')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (NULL, N'Phân tích viên', N'PT', 'HuanLuyen');
IF NOT EXISTS (SELECT 1 FROM DANH_MUC_VI_TRI WHERE ma_tro_choi IS NULL AND ky_hieu = N'QL')
    INSERT INTO DANH_MUC_VI_TRI (ma_tro_choi, ten_vi_tri, ky_hieu, loai_vi_tri) VALUES (NULL, N'Quản lý', N'QL', 'HuanLuyen');
GO

-- ==============================================================
-- SECTION 2 — IDENTITY & USER
-- ==============================================================

-- ---------------------------------------------------------------
-- 2.1  NGUOI_DUNG
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'NGUOI_DUNG')
BEGIN
    CREATE TABLE NGUOI_DUNG (
        ma_nguoi_dung     INT           IDENTITY PRIMARY KEY,
        ten_dang_nhap     NVARCHAR(100) NOT NULL,
        email             NVARCHAR(150) NOT NULL,
        mat_khau_ma_hoa   NVARCHAR(255) NOT NULL,
        vai_tro_he_thong  NVARCHAR(10)  NOT NULL CONSTRAINT DF_ND_VAITRO  DEFAULT 'user',
        avatar_url        NVARCHAR(400) NULL,
        bio               NVARCHAR(500) NULL,
        is_banned         BIT           NOT NULL CONSTRAINT DF_ND_BANNED  DEFAULT 0,
        ly_do_ban         NVARCHAR(500) NULL,
        thoi_gian_ban     DATETIME      NULL,
        ma_admin_ban      INT           NULL,
        ngay_tao          DATETIME      NOT NULL CONSTRAINT DF_ND_NGAYTAO DEFAULT GETDATE(),

        CONSTRAINT UQ_ND_USERNAME CHECK (ten_dang_nhap IS NOT NULL), -- NOT NULL enforced here
        CONSTRAINT UQ_ND_EMAIL    UNIQUE (email),
        CONSTRAINT UQ_ND_TENDANGNHAP UNIQUE (ten_dang_nhap),
        CONSTRAINT CHK_ND_VAITRO  CHECK (vai_tro_he_thong IN ('admin','user')),
        CONSTRAINT FK_ND_ADMIN_BAN FOREIGN KEY (ma_admin_ban) REFERENCES NGUOI_DUNG(ma_nguoi_dung)
    );
END
GO

-- ---------------------------------------------------------------
-- 2.2  HO_SO_IN_GAME  (1 user × 1 game = 1 profile)
--
-- Ban huấn luyện: in_game_id / in_game_name có thể NULL
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'HO_SO_IN_GAME')
BEGIN
    CREATE TABLE HO_SO_IN_GAME (
        ma_ho_so             INT           IDENTITY PRIMARY KEY,
        ma_nguoi_dung        INT           NOT NULL,
        ma_tro_choi          INT           NOT NULL,
        in_game_id           NVARCHAR(100) NULL,   -- Optional cho BanHuanLuyen
        in_game_name         NVARCHAR(100) NULL,   -- Optional cho BanHuanLuyen
        ma_vi_tri_so_truong  INT           NULL,   -- Vị trí sở trường
        thanh_tich           NVARCHAR(1000) NULL,
        ngay_cap_nhat        DATETIME      NOT NULL CONSTRAINT DF_HSG_UPDATE DEFAULT GETDATE(),

        CONSTRAINT UQ_HSG_PROFILE  UNIQUE (ma_nguoi_dung, ma_tro_choi),
        CONSTRAINT FK_HSG_ND       FOREIGN KEY (ma_nguoi_dung)       REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_HSG_TC       FOREIGN KEY (ma_tro_choi)         REFERENCES TRO_CHOI(ma_tro_choi),
        CONSTRAINT FK_HSG_VITRI    FOREIGN KEY (ma_vi_tri_so_truong) REFERENCES DANH_MUC_VI_TRI(ma_vi_tri)
    );
END
GO

-- ==============================================================
-- SECTION 3 — TEAM & SQUAD
-- ==============================================================

-- ---------------------------------------------------------------
-- 3.1  DOI  (Organisation / Club)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'DOI')
BEGIN
    CREATE TABLE DOI (
        ma_doi      INT           IDENTITY PRIMARY KEY,
        ten_doi     NVARCHAR(150) NOT NULL,
        ten_viet_tat NVARCHAR(20) NULL,       -- Tên viết tắt/tag của đội
        ma_doi_truong INT         NOT NULL,   -- Người tạo / chủ đội
        ma_manager  INT           NULL,       -- Manager (có thể khác chủ đội)
        logo_url    NVARCHAR(400) NULL,
        slogan      NVARCHAR(300) NULL,
        mo_ta       NVARCHAR(500) NULL,
        trang_thai  NVARCHAR(30)  NOT NULL CONSTRAINT DF_DOI_TRANGTHAI DEFAULT 'dang_hoat_dong',
        dang_tuyen  BIT           NOT NULL CONSTRAINT DF_DOI_DANGTUYEN DEFAULT 0,
        ngay_tao    DATETIME      NOT NULL CONSTRAINT DF_DOI_NGAYTAO   DEFAULT GETDATE(),

        CONSTRAINT CHK_DOI_TRANGTHAI CHECK (trang_thai IN ('dang_hoat_dong','tam_dung','da_giai_the')),
        CONSTRAINT FK_DOI_DOITRUONG FOREIGN KEY (ma_doi_truong) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_DOI_MANAGER  FOREIGN KEY (ma_manager)    REFERENCES NGUOI_DUNG(ma_nguoi_dung)
    );
END
GO

-- ---------------------------------------------------------------
-- 3.2  NHOM_DOI  (Squad per game under a club)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'NHOM_DOI')
BEGIN
    CREATE TABLE NHOM_DOI (
        ma_nhom           INT           IDENTITY PRIMARY KEY,
        ma_doi            INT           NOT NULL,
        ma_tro_choi       INT           NULL,  -- NULL for management group
        ten_nhom          NVARCHAR(150) NOT NULL,
        ma_doi_truong_nhom INT          NULL,   -- Squad captain

        CONSTRAINT FK_NHOM_DOI    FOREIGN KEY (ma_doi)             REFERENCES DOI(ma_doi),
        CONSTRAINT FK_NHOM_TC     FOREIGN KEY (ma_tro_choi)        REFERENCES TRO_CHOI(ma_tro_choi),
        CONSTRAINT FK_NHOM_CAP    FOREIGN KEY (ma_doi_truong_nhom) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT UQ_NHOM_DOI_GAME_TEN UNIQUE (ma_doi, ma_tro_choi, ten_nhom)
    );
END
GO

-- ---------------------------------------------------------------
-- 3.3  THANH_VIEN_DOI  (Squad membership)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'THANH_VIEN_DOI')
BEGIN
    CREATE TABLE THANH_VIEN_DOI (
        ma_thanh_vien      INT          IDENTITY PRIMARY KEY,
        ma_nguoi_dung      INT          NOT NULL,
        ma_nhom            INT          NULL,          -- NULL = team member without squad, 0 = management group (nhóm quản lý)
        ma_vi_tri          INT          NULL,
        vai_tro_noi_bo     NVARCHAR(20) NOT NULL CONSTRAINT DF_TV_VAITRO    DEFAULT 'thanh_vien',
        phan_he            NVARCHAR(20) NOT NULL CONSTRAINT DF_TV_PHANHE    DEFAULT 'TuyenThu',
        trang_thai_duyet   NVARCHAR(20) NOT NULL CONSTRAINT DF_TV_DUYET     DEFAULT 'da_duyet',
        trang_thai_hop_dong NVARCHAR(20) NOT NULL CONSTRAINT DF_TV_HOPDONG  DEFAULT 'dang_hieu_luc',
        ngay_tham_gia      DATETIME     NOT NULL CONSTRAINT DF_TV_NGAYTG    DEFAULT GETDATE(),

        CONSTRAINT FK_TV_ND       FOREIGN KEY (ma_nguoi_dung) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_TV_NHOM     FOREIGN KEY (ma_nhom)       REFERENCES NHOM_DOI(ma_nhom),
        CONSTRAINT FK_TV_VITRI    FOREIGN KEY (ma_vi_tri)     REFERENCES DANH_MUC_VI_TRI(ma_vi_tri),
        CONSTRAINT CHK_TV_VAITRO  CHECK (vai_tro_noi_bo     IN ('chu_tich','ban_dieu_hanh','doi_truong','thanh_vien')),
        CONSTRAINT CHK_TV_PHANHE  CHECK (phan_he             IN ('TuyenThu','HuanLuyen')),
        CONSTRAINT CHK_TV_DUYET   CHECK (trang_thai_duyet    IN ('cho_duyet','da_duyet','bi_tu_choi')),
        CONSTRAINT CHK_TV_HOPDONG CHECK (trang_thai_hop_dong IN ('dang_hieu_luc','tu_do','da_giai_phong'))
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.triggers WHERE name = 'TRG_THANH_VIEN_DOI_RULES')
BEGIN
    EXEC('
    CREATE TRIGGER TRG_THANH_VIEN_DOI_RULES
    ON THANH_VIEN_DOI
    AFTER INSERT, UPDATE
    AS
    BEGIN
        SET NOCOUNT ON;

        IF EXISTS (
            SELECT 1
            FROM inserted i
            INNER JOIN THANH_VIEN_DOI tv ON i.ma_nguoi_dung = tv.ma_nguoi_dung
            INNER JOIN NHOM_DOI ni ON i.ma_nhom = ni.ma_nhom
            INNER JOIN NHOM_DOI ntv ON tv.ma_nhom = ntv.ma_nhom
            WHERE i.trang_thai_duyet = ''da_duyet''
              AND i.trang_thai_hop_dong = ''dang_hieu_luc''
              AND tv.trang_thai_duyet = ''da_duyet''
              AND tv.trang_thai_hop_dong = ''dang_hieu_luc''
              AND ni.ma_tro_choi = ntv.ma_tro_choi
              AND i.ma_thanh_vien <> tv.ma_thanh_vien
        )
        BEGIN
            RAISERROR (N''Một người dùng chỉ được tham gia một đội trong cùng một game.'', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END;

        IF EXISTS (
            SELECT 1
            FROM THANH_VIEN_DOI tv
            INNER JOIN inserted i ON tv.ma_nhom = i.ma_nhom
            WHERE tv.vai_tro_noi_bo = ''doi_truong''
              AND tv.trang_thai_duyet = ''da_duyet''
              AND tv.trang_thai_hop_dong = ''dang_hieu_luc''
            GROUP BY tv.ma_nhom
            HAVING COUNT(*) > 1
        )
        BEGIN
            RAISERROR (N''Mỗi đội chỉ được có một đội trưởng.'', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END;
    END
    ');
END
GO

-- ==============================================================
-- SECTION 4 — RECRUITMENT
-- ==============================================================

-- ---------------------------------------------------------------
-- 4.1  BAI_DANG_TUYEN_DUNG  (Job posting by squad)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'BAI_DANG_TUYEN_DUNG')
BEGIN
    CREATE TABLE BAI_DANG_TUYEN_DUNG (
        ma_bai_dang INT           IDENTITY PRIMARY KEY,
        ma_doi      INT           NOT NULL,
        ma_nhom     INT           NOT NULL,
        ma_vi_tri   INT           NOT NULL,
        noi_dung    NVARCHAR(500) NOT NULL,
        trang_thai  NVARCHAR(20)  NOT NULL CONSTRAINT DF_BD_TRANGTHAI DEFAULT 'dang_mo',
        ngay_tao    DATETIME      NOT NULL CONSTRAINT DF_BD_NGAYTAO   DEFAULT GETDATE(),

        CONSTRAINT FK_BD_DOI    FOREIGN KEY (ma_doi)    REFERENCES DOI(ma_doi),
        CONSTRAINT FK_BD_NHOM   FOREIGN KEY (ma_nhom)   REFERENCES NHOM_DOI(ma_nhom),
        CONSTRAINT FK_BD_VITRI  FOREIGN KEY (ma_vi_tri) REFERENCES DANH_MUC_VI_TRI(ma_vi_tri),
        CONSTRAINT CHK_BD_TRANGTHAI CHECK (trang_thai IN ('dang_mo','tam_dong','da_dong'))
    );
END
GO

-- ---------------------------------------------------------------
-- 4.2  DON_UNG_TUYEN  (Application to a job posting)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'DON_UNG_TUYEN')
BEGIN
    CREATE TABLE DON_UNG_TUYEN (
        ma_don      INT          IDENTITY PRIMARY KEY,
        ma_bai_dang INT          NOT NULL,
        ma_ung_vien INT          NOT NULL,
        trang_thai  NVARCHAR(20) NOT NULL CONSTRAINT DF_DUT_TRANGTHAI DEFAULT 'cho_duyet',
        ngay_tao    DATETIME     NOT NULL CONSTRAINT DF_DUT_NGAYTAO   DEFAULT GETDATE(),

        CONSTRAINT FK_DUT_BAIDANG  FOREIGN KEY (ma_bai_dang) REFERENCES BAI_DANG_TUYEN_DUNG(ma_bai_dang),
        CONSTRAINT FK_DUT_UNGVIEN  FOREIGN KEY (ma_ung_vien) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT UQ_DUT_UNIQUE   UNIQUE (ma_bai_dang, ma_ung_vien),
        CONSTRAINT CHK_DUT_TRANGTHAI CHECK (trang_thai IN ('cho_duyet','chap_nhan','tu_choi'))
    );
END
GO

-- ---------------------------------------------------------------
-- 4.3  LOI_MOI_GIA_NHAP  (Invitation from squad to player)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'LOI_MOI_GIA_NHAP')
BEGIN
    CREATE TABLE LOI_MOI_GIA_NHAP (
        ma_loi_moi        INT          IDENTITY PRIMARY KEY,
        ma_doi            INT          NOT NULL,
        ma_nhom           INT          NULL,
        ma_nguoi_duoc_moi INT          NOT NULL,
        ma_nguoi_gui      INT          NULL,
        ma_vi_tri         INT          NULL,
        mo_ta             NVARCHAR(500) NULL,
        trang_thai        NVARCHAR(20) NOT NULL CONSTRAINT DF_LM_TRANGTHAI DEFAULT 'cho_phan_hoi',
        ngay_tao          DATETIME     NOT NULL CONSTRAINT DF_LM_NGAYTAO   DEFAULT GETDATE(),

        CONSTRAINT FK_LM_DOI       FOREIGN KEY (ma_doi)            REFERENCES DOI(ma_doi),
        CONSTRAINT FK_LM_NHOM      FOREIGN KEY (ma_nhom)           REFERENCES NHOM_DOI(ma_nhom),
        CONSTRAINT FK_LM_NGUOINHAN FOREIGN KEY (ma_nguoi_duoc_moi) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_LM_NGUOIGUI  FOREIGN KEY (ma_nguoi_gui)     REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_LM_VITRI     FOREIGN KEY (ma_vi_tri)        REFERENCES DANH_MUC_VI_TRI(ma_vi_tri),
        CONSTRAINT UQ_LM_UNIQUE    UNIQUE (ma_doi, ma_nhom, ma_nguoi_duoc_moi),
        CONSTRAINT CHK_LM_TRANGTHAI CHECK (trang_thai IN ('cho_phan_hoi','chap_nhan','tu_choi','da_het_han'))
    );
END
GO

-- ---------------------------------------------------------------
-- 4.3.1  YEU_CAU_MOI_THANH_VIEN_DOI  (Captain invite approval)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'YEU_CAU_MOI_THANH_VIEN_DOI')
BEGIN
    CREATE TABLE YEU_CAU_MOI_THANH_VIEN_DOI (
        ma_yeu_cau        INT          IDENTITY PRIMARY KEY,
        ma_doi            INT          NOT NULL,
        ma_nhom           INT          NOT NULL,
        ma_nguoi_duoc_moi INT          NOT NULL,
        ma_nguoi_gui      INT          NOT NULL,
        ma_vi_tri         INT          NULL,
        mo_ta             NVARCHAR(500) NULL,
        trang_thai        NVARCHAR(20) NOT NULL CONSTRAINT DF_YCMTV_TRANGTHAI DEFAULT 'cho_duyet',
        ngay_tao          DATETIME     NOT NULL CONSTRAINT DF_YCMTV_NGAYTAO DEFAULT GETDATE(),
        ngay_duyet        DATETIME     NULL,
        ma_nguoi_duyet    INT          NULL,

        CONSTRAINT FK_YCMTV_DOI        FOREIGN KEY (ma_doi)            REFERENCES DOI(ma_doi),
        CONSTRAINT FK_YCMTV_NHOM       FOREIGN KEY (ma_nhom)           REFERENCES NHOM_DOI(ma_nhom),
        CONSTRAINT FK_YCMTV_NGUOINHAN  FOREIGN KEY (ma_nguoi_duoc_moi) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_YCMTV_NGUOIGUI   FOREIGN KEY (ma_nguoi_gui)      REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_YCMTV_VITRI      FOREIGN KEY (ma_vi_tri)         REFERENCES DANH_MUC_VI_TRI(ma_vi_tri),
        CONSTRAINT FK_YCMTV_NGUOIDUYET FOREIGN KEY (ma_nguoi_duyet)    REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT CHK_YCMTV_TRANGTHAI CHECK (trang_thai IN ('cho_duyet','chap_nhan','tu_choi'))
    );
END
GO

-- ---------------------------------------------------------------
-- 4.4  XIN_GIA_NHAP  (Request from player to join squad)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'XIN_GIA_NHAP')
BEGIN
    CREATE TABLE XIN_GIA_NHAP (
        ma_don_xin   INT          IDENTITY PRIMARY KEY,
        ma_nguoi_dung INT          NOT NULL,
        ma_doi       INT          NOT NULL,
        ma_nhom      INT          NULL,
        ma_ho_so     INT          NULL,
        trang_thai   NVARCHAR(20) NOT NULL CONSTRAINT DF_XG_TRANGTHAI DEFAULT 'cho_duyet',
        ngay_tao     DATETIME     NOT NULL CONSTRAINT DF_XG_NGAYTAO   DEFAULT GETDATE(),

        CONSTRAINT FK_XG_ND    FOREIGN KEY (ma_nguoi_dung) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_XG_DOI   FOREIGN KEY (ma_doi)        REFERENCES DOI(ma_doi),
        CONSTRAINT FK_XG_NHOM  FOREIGN KEY (ma_nhom)       REFERENCES NHOM_DOI(ma_nhom),
        CONSTRAINT FK_XG_HOSO  FOREIGN KEY (ma_ho_so)     REFERENCES HO_SO_IN_GAME(ma_ho_so),
        CONSTRAINT UQ_XINGIANHAP UNIQUE (ma_nguoi_dung, ma_doi),
        CONSTRAINT CHK_XG_TRANGTHAI CHECK (trang_thai IN ('cho_duyet','chap_nhan','tu_choi'))
    );
END
GO

-- ---------------------------------------------------------------
-- 4.5  YEU_CAU_THAM_GIA_NHOM  (Squad join request with captain approval)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'YEU_CAU_THAM_GIA_NHOM')
BEGIN
    CREATE TABLE YEU_CAU_THAM_GIA_NHOM (
        ma_yeu_cau      INT          IDENTITY PRIMARY KEY,
        ma_nguoi_dung   INT          NOT NULL,
        ma_nhom         INT          NOT NULL,
        ma_ho_so        INT          NOT NULL,    -- Required game profile for the squad's game
        trang_thai      NVARCHAR(20) NOT NULL CONSTRAINT DF_YCTN_TRANGTHAI DEFAULT 'cho_duyet',
        ngay_tao        DATETIME     NOT NULL CONSTRAINT DF_YCTN_NGAYTAO   DEFAULT GETDATE(),
        ngay_duyet      DATETIME     NULL,
        ma_nguoi_duyet  INT          NULL,       -- Squad captain who approved/rejected

        CONSTRAINT FK_YCTN_ND       FOREIGN KEY (ma_nguoi_dung)  REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_YCTN_NHOM     FOREIGN KEY (ma_nhom)        REFERENCES NHOM_DOI(ma_nhom),
        CONSTRAINT FK_YCTN_HOSO     FOREIGN KEY (ma_ho_so)       REFERENCES HO_SO_IN_GAME(ma_ho_so),
        CONSTRAINT FK_YCTN_NGUOIDUYET FOREIGN KEY (ma_nguoi_duyet) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT UQ_YCTN_UNIQUE  UNIQUE (ma_nhom, ma_nguoi_dung),
        CONSTRAINT CHK_YCTN_TRANGTHAI CHECK (trang_thai IN ('cho_duyet','chap_nhan','tu_choi'))
    );
END
GO

-- ---------------------------------------------------------------
-- 4.6  YEU_CAU_XAC_NHAN_LOI_MOI  (Invite confirmation request)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'YEU_CAU_XAC_NHAN_LOI_MOI')
BEGIN
    CREATE TABLE YEU_CAU_XAC_NHAN_LOI_MOI (
        ma_yeu_cau         INT          IDENTITY PRIMARY KEY,
        ma_nguoi_gui       INT          NOT NULL,
        ma_doi             INT          NOT NULL,
        ma_nhom            INT          NULL,
        ma_nguoi_nhan      INT          NOT NULL,
        trang_thai         NVARCHAR(50) NOT NULL CONSTRAINT DF_YCXNLM_TRANGTHAI DEFAULT 'cho_xac_nhan',
        ngay_tao           DATETIME     NOT NULL CONSTRAINT DF_YCXNLM_NGAYTAO DEFAULT GETDATE(),
        ngay_xac_nhan      DATETIME     NULL,
        ma_nguoi_xac_nhan  INT          NULL,

        CONSTRAINT FK_YCXNLM_NGUOI_GUI      FOREIGN KEY (ma_nguoi_gui)      REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_YCXNLM_DOI            FOREIGN KEY (ma_doi)            REFERENCES DOI(ma_doi),
        CONSTRAINT FK_YCXNLM_NHOM           FOREIGN KEY (ma_nhom)           REFERENCES NHOM_DOI(ma_nhom),
        CONSTRAINT FK_YCXNLM_NGUOI_NHAN     FOREIGN KEY (ma_nguoi_nhan)     REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_YCXNLM_NGUOI_XAC_NHAN FOREIGN KEY (ma_nguoi_xac_nhan) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT CHK_YCXNLM_TRANGTHAI CHECK (trang_thai IN ('cho_xac_nhan', 'da_xac_nhan', 'tu_choi'))
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_YCXNLM_NguoiGui' AND object_id = OBJECT_ID('YEU_CAU_XAC_NHAN_LOI_MOI'))
BEGIN
    CREATE INDEX IX_YCXNLM_NguoiGui ON YEU_CAU_XAC_NHAN_LOI_MOI(ma_nguoi_gui);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_YCXNLM_Doi' AND object_id = OBJECT_ID('YEU_CAU_XAC_NHAN_LOI_MOI'))
BEGIN
    CREATE INDEX IX_YCXNLM_Doi ON YEU_CAU_XAC_NHAN_LOI_MOI(ma_doi);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_YCXNLM_NguoiNhan' AND object_id = OBJECT_ID('YEU_CAU_XAC_NHAN_LOI_MOI'))
BEGIN
    CREATE INDEX IX_YCXNLM_NguoiNhan ON YEU_CAU_XAC_NHAN_LOI_MOI(ma_nguoi_nhan);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_YCXNLM_TrangThai' AND object_id = OBJECT_ID('YEU_CAU_XAC_NHAN_LOI_MOI'))
BEGIN
    CREATE INDEX IX_YCXNLM_TrangThai ON YEU_CAU_XAC_NHAN_LOI_MOI(trang_thai);
END
GO

-- ==============================================================
-- SECTION 5 — TOURNAMENT
-- ==============================================================

-- ---------------------------------------------------------------
-- 5.1  GIAI_DAU  (Tournament)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'GIAI_DAU')
BEGIN
    CREATE TABLE GIAI_DAU (
        ma_giai_dau            INT            IDENTITY PRIMARY KEY,
        ten_giai_dau           NVARCHAR(150)  NOT NULL,
        ma_tro_choi            INT            NULL,    -- NULL = giải hỗn hợp
        ma_nguoi_tao           INT            NULL,
        the_thuc               NVARCHAR(50)   NOT NULL,
        banner_url             NVARCHAR(400)  NULL,
        mo_ta                  NVARCHAR(500)  NULL,
        kieu_tham_gia          NVARCHAR(20)   NOT NULL CONSTRAINT DF_GD_KIEU_THAM_GIA DEFAULT 'theo_doi',
        so_nguoi_moi_doi       INT            NULL,
        so_luong_doi_toi_da    INT            NULL,
        luat_giai              NVARCHAR(MAX)  NULL,
        thong_tin_lien_he      NVARCHAR(250)  NULL,
        che_do_cong_khai       NVARCHAR(30)   NOT NULL CONSTRAINT DF_GD_CHE_DO_CONG_KHAI DEFAULT 'cong_khai_sau_duyet',
        ngay_bat_dau           DATETIME       NULL,
        ngay_ket_thuc          DATETIME       NULL,
        thoi_gian_mo_dang_ky   DATETIME       NULL,
        thoi_gian_dong_dang_ky DATETIME       NULL,
        so_doi_toi_thieu       INT            NOT NULL CONSTRAINT DF_GD_DOI_TOI_THIEU DEFAULT 2,
        so_doi_toi_da          INT            NULL,
        dang_mo_dang_ky        BIT            NOT NULL CONSTRAINT DF_GD_MO_DANG_KY DEFAULT 0,
        tong_giai_thuong       DECIMAL(15,2)  NOT NULL CONSTRAINT DF_GD_GIAILTHUONG DEFAULT 0,
        trang_thai             NVARCHAR(30)   NOT NULL CONSTRAINT DF_GD_TRANGTHAI   DEFAULT 'nhap',
        hien_thi_public        BIT            NOT NULL CONSTRAINT DF_GD_PUBLIC      DEFAULT 1,
        is_deleted             BIT            NOT NULL CONSTRAINT DF_GD_DELETED     DEFAULT 0,
        thoi_gian_bat_dau_tam_hoan DATETIME   NULL,
        thoi_gian_ket_thuc_tam_hoan DATETIME  NULL,
        thoi_gian_tam_hoan_total INT          NULL,
        thoi_gian_khoa         DATETIME       NULL,
        ma_nguoi_khoa          INT            NULL,
        ly_do_khoa             NVARCHAR(500)  NULL,

        CONSTRAINT FK_GD_TC        FOREIGN KEY (ma_tro_choi)   REFERENCES TRO_CHOI(ma_tro_choi),
        CONSTRAINT FK_GD_NGUOITAO  FOREIGN KEY (ma_nguoi_tao)  REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_GD_NGUOIKHOA FOREIGN KEY (ma_nguoi_khoa) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT CHK_GD_THETHUC  CHECK (the_thuc IN (
            'loai_truc_tiep','nhanh_thang_nhanh_thua',
            'dau_theo_bang','vong_tron_tinh_diem','hon_hop'
        )),
        CONSTRAINT CHK_GD_TRANGTHAI CHECK (trang_thai IN (
            'nhap','cho_xet_duyet','chuan_bi_dien_ra','dang_dien_ra',
            'tong_ket','ket_thuc','tam_hoan','khoa'
        )),
        CONSTRAINT CHK_GD_KIEU_THAM_GIA CHECK (kieu_tham_gia IN ('theo_doi','ca_nhan')),
        CONSTRAINT CHK_GD_CHE_DO_CONG_KHAI CHECK (che_do_cong_khai IN ('cong_khai_sau_duyet','rieng_tu')),
        CONSTRAINT CHK_GD_SO_NGUOI_MOI_DOI CHECK (so_nguoi_moi_doi IS NULL OR so_nguoi_moi_doi > 0),
        CONSTRAINT CHK_GD_SO_LUONG_DOI_TOI_DA CHECK (so_luong_doi_toi_da IS NULL OR so_luong_doi_toi_da >= 2),
        CONSTRAINT CHK_GD_THOIGIAN_DANGKY CHECK (
            thoi_gian_dong_dang_ky IS NULL
            OR ngay_bat_dau IS NULL
            OR thoi_gian_dong_dang_ky < ngay_bat_dau
        )
    );
END
GO

-- ---------------------------------------------------------------
-- 5.2  QUAN_TRI_GIAI_DAU  (BTC / Referee assignment per tournament)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'QUAN_TRI_GIAI_DAU')
BEGIN
    CREATE TABLE QUAN_TRI_GIAI_DAU (
        ma_giai_dau  INT         NOT NULL,
        ma_nguoi_dung INT        NOT NULL,
        vai_tro_giai NVARCHAR(20) NOT NULL,

        CONSTRAINT PK_QTGD        PRIMARY KEY (ma_giai_dau, ma_nguoi_dung),
        CONSTRAINT FK_QTGD_GD     FOREIGN KEY (ma_giai_dau)   REFERENCES GIAI_DAU(ma_giai_dau),
        CONSTRAINT FK_QTGD_ND     FOREIGN KEY (ma_nguoi_dung) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT CHK_QTGD_VAITRO CHECK (vai_tro_giai IN ('ban_to_chuc','trong_tai'))
    );
END
GO

-- ---------------------------------------------------------------
-- 5.3  YEU_CAU_TAO_GIAI_DAU  (Tournament creation request)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'YEU_CAU_TAO_GIAI_DAU')
BEGIN
    CREATE TABLE YEU_CAU_TAO_GIAI_DAU (
        ma_yeu_cau      INT            IDENTITY PRIMARY KEY,
        ma_nguoi_gui    INT            NOT NULL,
        ten_giai_dau    NVARCHAR(150)  NOT NULL,
        ma_tro_choi     INT            NULL,
        the_thuc        NVARCHAR(50)   NOT NULL,
        ngay_bat_dau    DATETIME       NOT NULL,
        ngay_ket_thuc   DATETIME       NOT NULL,
        tong_giai_thuong DECIMAL(15,2) NOT NULL,
        trang_thai      NVARCHAR(20)   NOT NULL CONSTRAINT DF_YCTGD_TRANGTHAI DEFAULT 'cho_duyet',
        ma_admin_duyet  INT            NULL,
        ly_do_huy       NVARCHAR(500)  NULL,
        thoi_gian_gui   DATETIME       NOT NULL CONSTRAINT DF_YCTGD_THOIGIANGUI DEFAULT GETDATE(),
        thoi_gian_duyet DATETIME       NULL,

        CONSTRAINT FK_YCTGD_NGUOIGUI FOREIGN KEY (ma_nguoi_gui)   REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_YCTGD_TC       FOREIGN KEY (ma_tro_choi)    REFERENCES TRO_CHOI(ma_tro_choi),
        CONSTRAINT FK_YCTGD_ADMIN    FOREIGN KEY (ma_admin_duyet) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT CHK_YCTGD_TRANGTHAI CHECK (trang_thai IN ('cho_duyet','da_duyet','tu_choi'))
    );
END
GO

-- ---------------------------------------------------------------
-- 5.4  THAM_GIA_GIAI  (Squad registration to a tournament)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'THAM_GIA_GIAI')
BEGIN
    CREATE TABLE THAM_GIA_GIAI (
        ma_tham_gia        INT          IDENTITY PRIMARY KEY,
        ma_giai_dau        INT          NOT NULL,
        ma_nhom            INT          NOT NULL,
        trang_thai_duyet   NVARCHAR(20) NOT NULL CONSTRAINT DF_TGG_DUYET    DEFAULT 'cho_duyet',
        trang_thai_tham_gia NVARCHAR(20) NOT NULL CONSTRAINT DF_TGG_THAMGIA DEFAULT 'dang_thi_dau',
        hat_giong          INT          NULL,

        CONSTRAINT FK_TGG_GD     FOREIGN KEY (ma_giai_dau) REFERENCES GIAI_DAU(ma_giai_dau),
        CONSTRAINT FK_TGG_NHOM   FOREIGN KEY (ma_nhom)     REFERENCES NHOM_DOI(ma_nhom),
        CONSTRAINT UQ_TGG_GD_NHOM UNIQUE (ma_giai_dau, ma_nhom),
        CONSTRAINT CHK_TGG_DUYET   CHECK (trang_thai_duyet    IN ('cho_duyet','da_duyet','bi_tu_choi')),
        CONSTRAINT CHK_TGG_THAMGIA CHECK (trang_thai_tham_gia IN ('dang_thi_dau','di_tiep','bi_loai'))
    );
END
GO

-- ---------------------------------------------------------------
-- 5.5  DOI_HINH_THI_DAU  (Tournament roster)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'DOI_HINH_THI_DAU')
BEGIN
    CREATE TABLE DOI_HINH_THI_DAU (
        ma_doi_hinh  INT  IDENTITY PRIMARY KEY,
        ma_tham_gia  INT  NOT NULL,
        ma_giai_dau  INT  NOT NULL,   -- Denormalised for quick UNIQUE check
        ma_nguoi_dung INT NOT NULL,
        ma_vi_tri    INT  NULL,
        is_du_bi     BIT  NOT NULL CONSTRAINT DF_DHTS_DUBI DEFAULT 0,

        CONSTRAINT FK_DHTS_THAMGIA  FOREIGN KEY (ma_tham_gia)  REFERENCES THAM_GIA_GIAI(ma_tham_gia),
        CONSTRAINT FK_DHTS_GD       FOREIGN KEY (ma_giai_dau)  REFERENCES GIAI_DAU(ma_giai_dau),
        CONSTRAINT FK_DHTS_ND       FOREIGN KEY (ma_nguoi_dung) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_DHTS_VITRI    FOREIGN KEY (ma_vi_tri)    REFERENCES DANH_MUC_VI_TRI(ma_vi_tri),
        -- One player cannot be in two rosters of the same tournament
        CONSTRAINT UQ_DHTS_GD_PLAYER UNIQUE (ma_giai_dau, ma_nguoi_dung)
    );
END
GO

-- ---------------------------------------------------------------
-- 5.6  GIAI_THUONG  (Prize structure)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'GIAI_THUONG')
BEGIN
    CREATE TABLE GIAI_THUONG (
        ma_giai_thuong INT            IDENTITY PRIMARY KEY,
        ma_giai_dau    INT            NOT NULL,
        vi_tri_top     INT            NULL,
        so_tien        DECIMAL(15,2)  NULL,
        ten_giai       NVARCHAR(150)  NULL,
        gia_tri        DECIMAL(15,2)  NOT NULL CONSTRAINT DF_GT_GIA_TRI DEFAULT 0,
        so_luong       INT            NOT NULL CONSTRAINT DF_GT_SO_LUONG DEFAULT 1,
        mo_ta          NVARCHAR(500)  NULL,

        CONSTRAINT FK_GT_GD  FOREIGN KEY (ma_giai_dau) REFERENCES GIAI_DAU(ma_giai_dau),
        CONSTRAINT CHK_GT_VITRI CHECK (vi_tri_top IS NULL OR vi_tri_top > 0),
        CONSTRAINT CHK_GT_SOTIEN CHECK (so_tien IS NULL OR so_tien >= 0),
        CONSTRAINT CHK_GT_GIA_TRI CHECK (gia_tri >= 0),
        CONSTRAINT CHK_GT_SO_LUONG CHECK (so_luong > 0)
    );
END
GO

-- ==============================================================
-- SECTION 6 — TOURNAMENT STAGE & BRACKET
-- ==============================================================

-- ---------------------------------------------------------------
-- 6.1  GIAI_DOAN  (Stage / Phase of a tournament)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'GIAI_DOAN')
BEGIN
    CREATE TABLE GIAI_DOAN (
        ma_giai_doan          INT           IDENTITY PRIMARY KEY,
        ma_giai_dau           INT           NOT NULL,
        ten_giai_doan         NVARCHAR(100) NOT NULL,
        the_thuc              NVARCHAR(50)  NOT NULL,
        thu_tu                INT           NOT NULL,
        ngay_bat_dau          DATETIME      NULL,
        ngay_ket_thuc         DATETIME      NULL,
        so_doi_di_tiep        INT           NOT NULL CONSTRAINT DF_GDO_DOIDITIEP DEFAULT 0,
        diem_nguong_match_point INT          NULL,
        trang_thai            NVARCHAR(30)  NOT NULL CONSTRAINT DF_GDO_TRANGTHAI DEFAULT 'chua_bat_dau',

        CONSTRAINT FK_GDO_GD      FOREIGN KEY (ma_giai_dau) REFERENCES GIAI_DAU(ma_giai_dau),
        CONSTRAINT CHK_GDO_THETHUC CHECK (the_thuc IN (
            'loai_truc_tiep','nhanh_thang_nhanh_thua',
            'vong_tron','league_bang_cheo','thuy_si','champion_rush'
        )),
        CONSTRAINT CHK_GDO_TRANGTHAI CHECK (trang_thai IN ('chua_bat_dau','dang_dien_ra','ket_thuc')),
        CONSTRAINT CHK_GDO_THUTHU  CHECK (thu_tu > 0),
        CONSTRAINT CHK_GDO_DOIDITIEP CHECK (so_doi_di_tiep >= 0),
        CONSTRAINT CHK_GDO_MATCHPOINT CHECK (diem_nguong_match_point IS NULL OR diem_nguong_match_point > 0),
        CONSTRAINT UQ_GDO_GD_THUTHU UNIQUE (ma_giai_dau, thu_tu)
    );
END
GO

-- ==============================================================
-- SECTION 7 — MATCH & RESULTS
-- ==============================================================

-- ---------------------------------------------------------------
-- 7.1  TRAN_DAU  (Match)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'TRAN_DAU')
BEGIN
    CREATE TABLE TRAN_DAU (
        ma_tran                INT           IDENTITY PRIMARY KEY,
        ma_giai_dau            INT           NOT NULL,
        ma_giai_doan           INT           NULL,
        ma_trong_tai           INT           NULL,
        vong_dau               NVARCHAR(100) NULL,
        the_thuc_tran          NVARCHAR(20)  NOT NULL,
        so_vong                INT           NULL,
        nhanh_dau              NVARCHAR(30)  NULL,    -- winners/losers bracket
        ma_tran_tiep_theo_thang INT          NULL,
        ma_tran_tiep_theo_thua  INT          NULL,
        thoi_gian_bat_dau      DATETIME      NULL,
        thoi_gian_ket_thuc     DATETIME      NULL,
        thoi_gian_nhap_diem    DATETIME      NULL,
        so_lan_sua             INT           NOT NULL CONSTRAINT DF_TD_SOLANSUA DEFAULT 0,
        cho_phep_sua_den       DATETIME      NULL,
        trang_thai             NVARCHAR(20)  NOT NULL CONSTRAINT DF_TD_TRANGTHAI DEFAULT 'chua_dau',

        CONSTRAINT FK_TD_GD        FOREIGN KEY (ma_giai_dau)             REFERENCES GIAI_DAU(ma_giai_dau),
        CONSTRAINT FK_TD_GDO       FOREIGN KEY (ma_giai_doan)            REFERENCES GIAI_DOAN(ma_giai_doan),
        CONSTRAINT FK_TD_TRONGTAL FOREIGN KEY (ma_trong_tai) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_TD_NEXT_WIN  FOREIGN KEY (ma_tran_tiep_theo_thang) REFERENCES TRAN_DAU(ma_tran),
        CONSTRAINT FK_TD_NEXT_LOSE FOREIGN KEY (ma_tran_tiep_theo_thua)  REFERENCES TRAN_DAU(ma_tran),
        CONSTRAINT CHK_TD_TRANGTHAI CHECK (trang_thai IN ('chua_dau','dang_dau','da_hoan_thanh','huy_bo')),
        CONSTRAINT CHK_TD_THETHUCTRAN CHECK (the_thuc_tran IN ('BO1','BO3','BO5','SinhTon'))
    );
END
GO

-- ---------------------------------------------------------------
-- 7.2  CHI_TIET_TRAN_DAU  (Per-team score in a match)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'CHI_TIET_TRAN_DAU')
BEGIN
    CREATE TABLE CHI_TIET_TRAN_DAU (
        ma_tran   INT          NOT NULL,
        ma_nhom   INT          NOT NULL,
        diem_so   FLOAT        NOT NULL CONSTRAINT DF_CTTD_DIEM DEFAULT 0,
        thu_hang  INT          NULL,     -- Battle Royale placement
        ket_qua   NVARCHAR(10) NULL,     -- 'thang','thua','hoa' (MOBA/FPS)

        CONSTRAINT PK_CTTD     PRIMARY KEY (ma_tran, ma_nhom),
        CONSTRAINT FK_CTTD_TD  FOREIGN KEY (ma_tran) REFERENCES TRAN_DAU(ma_tran),
        CONSTRAINT FK_CTTD_NHOM FOREIGN KEY (ma_nhom) REFERENCES NHOM_DOI(ma_nhom),
        CONSTRAINT CHK_CTTD_KETQUA CHECK (ket_qua IS NULL OR ket_qua IN ('thang','thua','hoa'))
    );
END
GO

-- ---------------------------------------------------------------
-- 7.3  KET_QUA_TRAN  (Match result summary / audit header)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'KET_QUA_TRAN')
BEGIN
    CREATE TABLE KET_QUA_TRAN (
        ma_ket_qua              INT          IDENTITY PRIMARY KEY,
        ma_tran                 INT          NOT NULL,
        thoi_diem_bao_cao_dau_tien DATETIME  NOT NULL CONSTRAINT DF_KQT_THOIGIAN DEFAULT GETDATE(),
        so_lan_chinh_sua        INT          NOT NULL CONSTRAINT DF_KQT_SOLAN    DEFAULT 0,
        thoi_gian_sua_cuoi      DATETIME     NULL,
        chi_tiet_phu            NVARCHAR(MAX) NULL,    -- JSON log

        CONSTRAINT UQ_KQT_TRAN UNIQUE (ma_tran),
        CONSTRAINT FK_KQT_TD   FOREIGN KEY (ma_tran) REFERENCES TRAN_DAU(ma_tran)
    );
END
GO

-- ---------------------------------------------------------------
-- 7.4  LICH_SU_SUA_KET_QUA  (Immutable audit log)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'LICH_SU_SUA_KET_QUA')
BEGIN
    CREATE TABLE LICH_SU_SUA_KET_QUA (
        ma_log      INT           IDENTITY PRIMARY KEY,
        ma_tran     INT           NOT NULL,
        nguoi_sua   INT           NULL,
        thoi_gian_sua DATETIME    NOT NULL CONSTRAINT DF_LSSKQ_TG DEFAULT GETDATE(),
        du_lieu_cu  NVARCHAR(MAX) NULL,
        du_lieu_moi NVARCHAR(MAX) NULL,
        ly_do_sua   NVARCHAR(MAX) NULL,

        CONSTRAINT FK_LSSKQ_TD       FOREIGN KEY (ma_tran)    REFERENCES TRAN_DAU(ma_tran),
        CONSTRAINT FK_LSSKQ_NGUOISUA FOREIGN KEY (nguoi_sua)  REFERENCES NGUOI_DUNG(ma_nguoi_dung)
    );
END
GO

-- Audit log: bất biến — không cho UPDATE hoặc DELETE
IF NOT EXISTS (SELECT 1 FROM sys.triggers WHERE name = 'TRG_LSSKQ_IMMUTABLE' AND parent_class_desc = 'OBJECT_OR_COLUMN')
BEGIN
    EXEC('
    CREATE TRIGGER TRG_LSSKQ_IMMUTABLE
    ON LICH_SU_SUA_KET_QUA
    INSTEAD OF UPDATE, DELETE
    AS
    BEGIN
        SET NOCOUNT ON;
        RAISERROR(N''LICH_SU_SUA_KET_QUA là audit log bất biến. Không được phép UPDATE/DELETE.'', 16, 1);
    END;');
END
GO

-- ---------------------------------------------------------------
-- 7.5  KHIEU_NAI_KET_QUA  (Result dispute)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'KHIEU_NAI_KET_QUA')
BEGIN
    CREATE TABLE KHIEU_NAI_KET_QUA (
        ma_khieu_nai   INT           IDENTITY PRIMARY KEY,
        ma_tran        INT           NOT NULL,
        ma_nhom        INT           NOT NULL,
        ma_nguoi_gui   INT           NOT NULL,
        noi_dung       NVARCHAR(MAX) NOT NULL,
        trang_thai     NVARCHAR(20)  NOT NULL CONSTRAINT DF_KN_TRANGTHAI DEFAULT 'cho_xu_ly',
        ma_admin_xu_ly INT           NULL,
        phan_hoi_admin NVARCHAR(MAX) NULL,
        thoi_gian_tao  DATETIME      NOT NULL CONSTRAINT DF_KN_THOIGIANTAO DEFAULT GETDATE(),
        thoi_gian_xu_ly DATETIME     NULL,

        CONSTRAINT FK_KN_TD          FOREIGN KEY (ma_tran)        REFERENCES TRAN_DAU(ma_tran),
        CONSTRAINT FK_KN_NHOM        FOREIGN KEY (ma_nhom)        REFERENCES NHOM_DOI(ma_nhom),
        CONSTRAINT FK_KN_NGUOIGUI    FOREIGN KEY (ma_nguoi_gui)   REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_KN_ADMIN       FOREIGN KEY (ma_admin_xu_ly) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT CHK_KN_TRANGTHAI  CHECK (trang_thai IN ('cho_xu_ly','da_xu_ly','tu_choi'))
    );
END
GO

-- Filtered unique index: chỉ 1 khiếu nại đang chờ xử lý / (trận, đội)
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_KN_PENDING_TRAN_NHOM' AND object_id = OBJECT_ID('KHIEU_NAI_KET_QUA'))
BEGIN
    CREATE UNIQUE INDEX UX_KN_PENDING_TRAN_NHOM
    ON KHIEU_NAI_KET_QUA(ma_tran, ma_nhom)
    WHERE trang_thai = 'cho_xu_ly';
END
GO

-- ---------------------------------------------------------------
-- 7.6  YEU_CAU_MO_KHOA_KET_QUA  (Referee unlock-result request)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'YEU_CAU_MO_KHOA_KET_QUA')
BEGIN
    CREATE TABLE YEU_CAU_MO_KHOA_KET_QUA (
        ma_yeu_cau            INT            IDENTITY PRIMARY KEY,
        ma_tran               INT            NOT NULL,
        ma_trong_tai_yeu_cau  INT            NOT NULL,
        ly_do_yeu_cau         NVARCHAR(1000) NOT NULL,
        trang_thai            NVARCHAR(20)   NOT NULL CONSTRAINT DF_YCMK_TRANGTHAI DEFAULT 'cho_duyet',
        phan_hoi_admin        NVARCHAR(1000) NULL,
        ma_admin_xu_ly        INT            NULL,
        thoi_gian_tao         DATETIME       NOT NULL CONSTRAINT DF_YCMK_TAO DEFAULT GETDATE(),
        thoi_gian_xu_ly       DATETIME       NULL,
        thoi_gian_mo_khoa_den DATETIME       NULL,

        CONSTRAINT FK_YCMK_TRAN_DAU   FOREIGN KEY (ma_tran)              REFERENCES TRAN_DAU(ma_tran),
        CONSTRAINT FK_YCMK_TRONG_TAI  FOREIGN KEY (ma_trong_tai_yeu_cau) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_YCMK_ADMIN_XULY FOREIGN KEY (ma_admin_xu_ly)       REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT CHK_YCMK_TRANGTHAI CHECK (trang_thai IN ('cho_duyet','da_duyet','tu_choi'))
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_YCMK_PENDING_TRAN' AND object_id = OBJECT_ID('YEU_CAU_MO_KHOA_KET_QUA'))
BEGIN
    CREATE UNIQUE INDEX UX_YCMK_PENDING_TRAN
    ON YEU_CAU_MO_KHOA_KET_QUA(ma_tran)
    WHERE trang_thai = 'cho_duyet';
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_YCMK_TRANGTHAI_TAO' AND object_id = OBJECT_ID('YEU_CAU_MO_KHOA_KET_QUA'))
BEGIN
    CREATE INDEX IX_YCMK_TRANGTHAI_TAO
    ON YEU_CAU_MO_KHOA_KET_QUA(trang_thai, thoi_gian_tao DESC);
END
GO

-- ---------------------------------------------------------------
-- 7.x  Schema sync for existing databases (idempotent patch)
-- ---------------------------------------------------------------
IF COL_LENGTH('dbo.GIAI_DAU', 'so_doi_toi_thieu') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_DAU
    ADD so_doi_toi_thieu INT NOT NULL CONSTRAINT DF_GD_DOI_TOI_THIEU_PATCH DEFAULT 2;
END
GO

IF COL_LENGTH('dbo.GIAI_DAU', 'so_doi_toi_da') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_DAU
    ADD so_doi_toi_da INT NULL;
END
GO

IF COL_LENGTH('dbo.GIAI_DAU', 'dang_mo_dang_ky') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_DAU
    ADD dang_mo_dang_ky BIT NOT NULL CONSTRAINT DF_GD_MO_DANG_KY_PATCH DEFAULT 0;
END
GO

IF COL_LENGTH('dbo.TRAN_DAU', 'cho_phep_sua_den') IS NULL
BEGIN
    ALTER TABLE dbo.TRAN_DAU
    ADD cho_phep_sua_den DATETIME NULL;
END
GO

IF COL_LENGTH('dbo.GIAI_DAU', 'mo_ta') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_DAU
    ADD mo_ta NVARCHAR(500) NULL;
END
GO

IF COL_LENGTH('dbo.GIAI_DAU', 'kieu_tham_gia') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_DAU
    ADD kieu_tham_gia NVARCHAR(20) NOT NULL CONSTRAINT DF_GD_KIEU_THAM_GIA_PATCH DEFAULT 'theo_doi';
END
GO

IF COL_LENGTH('dbo.GIAI_DAU', 'so_luong_doi_toi_da') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_DAU
    ADD so_luong_doi_toi_da INT NULL;
END
GO

IF COL_LENGTH('dbo.GIAI_DAU', 'luat_giai') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_DAU
    ADD luat_giai NVARCHAR(MAX) NULL;
END
GO

IF COL_LENGTH('dbo.GIAI_DAU', 'thong_tin_lien_he') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_DAU
    ADD thong_tin_lien_he NVARCHAR(250) NULL;
END
GO

IF COL_LENGTH('dbo.GIAI_DAU', 'che_do_cong_khai') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_DAU
    ADD che_do_cong_khai NVARCHAR(30) NOT NULL CONSTRAINT DF_GD_CHE_DO_CONG_KHAI_PATCH DEFAULT 'cong_khai_sau_duyet';
END
GO

IF COL_LENGTH('dbo.GIAI_DAU', 'thoi_gian_bat_dau_tam_hoan') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_DAU
    ADD thoi_gian_bat_dau_tam_hoan DATETIME NULL;
END
GO

IF COL_LENGTH('dbo.GIAI_DAU', 'thoi_gian_ket_thuc_tam_hoan') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_DAU
    ADD thoi_gian_ket_thuc_tam_hoan DATETIME NULL;
END
GO

IF COL_LENGTH('dbo.GIAI_DAU', 'thoi_gian_tam_hoan_total') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_DAU
    ADD thoi_gian_tam_hoan_total INT NULL;
END
GO

IF COL_LENGTH('dbo.GIAI_DOAN', 'ngay_bat_dau') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_DOAN
    ADD ngay_bat_dau DATETIME NULL;
END
GO

IF COL_LENGTH('dbo.GIAI_DOAN', 'ngay_ket_thuc') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_DOAN
    ADD ngay_ket_thuc DATETIME NULL;
END
GO

IF COL_LENGTH('dbo.GIAI_THUONG', 'ten_giai') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_THUONG
    ADD ten_giai NVARCHAR(150) NULL;
END
GO

IF COL_LENGTH('dbo.GIAI_THUONG', 'gia_tri') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_THUONG
    ADD gia_tri DECIMAL(15,2) NOT NULL CONSTRAINT DF_GT_GIA_TRI_PATCH DEFAULT 0;
END
GO

IF COL_LENGTH('dbo.GIAI_THUONG', 'so_luong') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_THUONG
    ADD so_luong INT NOT NULL CONSTRAINT DF_GT_SO_LUONG_PATCH DEFAULT 1;
END
GO

IF COL_LENGTH('dbo.GIAI_THUONG', 'mo_ta') IS NULL
BEGIN
    ALTER TABLE dbo.GIAI_THUONG
    ADD mo_ta NVARCHAR(500) NULL;
END
GO

IF EXISTS (
    SELECT 1
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'NHOM_DOI'
      AND COLUMN_NAME = 'ma_tro_choi'
      AND IS_NULLABLE = 'NO'
)
BEGIN
    IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_NHOM_TC' AND parent_object_id = OBJECT_ID('dbo.NHOM_DOI'))
    BEGIN
        ALTER TABLE dbo.NHOM_DOI DROP CONSTRAINT FK_NHOM_TC;
    END

    ALTER TABLE dbo.NHOM_DOI ALTER COLUMN ma_tro_choi INT NULL;
    ALTER TABLE dbo.NHOM_DOI ADD CONSTRAINT FK_NHOM_TC FOREIGN KEY (ma_tro_choi) REFERENCES TRO_CHOI(ma_tro_choi);
END
GO

IF COL_LENGTH('dbo.DOI', 'ten_viet_tat') IS NULL
BEGIN
    ALTER TABLE dbo.DOI ADD ten_viet_tat NVARCHAR(20) NULL;
END
GO

UPDATE dbo.GIAI_DAU
SET trang_thai = CASE trang_thai
    WHEN 'ban_nhap' THEN 'nhap'
    WHEN 'cho_phe_duyet' THEN 'cho_xet_duyet'
    WHEN 'mo_dang_ky' THEN 'chuan_bi_dien_ra'
    WHEN 'sap_dien_ra' THEN 'chuan_bi_dien_ra'
    ELSE trang_thai
END
WHERE trang_thai IN ('ban_nhap', 'cho_phe_duyet', 'mo_dang_ky', 'sap_dien_ra');
GO

IF EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = 'DF_GD_TRANGTHAI' AND parent_object_id = OBJECT_ID('dbo.GIAI_DAU'))
BEGIN
    ALTER TABLE dbo.GIAI_DAU DROP CONSTRAINT DF_GD_TRANGTHAI;
END
GO

ALTER TABLE dbo.GIAI_DAU ADD CONSTRAINT DF_GD_TRANGTHAI DEFAULT 'nhap' FOR trang_thai;
GO

IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CHK_GD_TRANGTHAI' AND parent_object_id = OBJECT_ID('dbo.GIAI_DAU'))
BEGIN
    ALTER TABLE dbo.GIAI_DAU DROP CONSTRAINT CHK_GD_TRANGTHAI;
END
GO

ALTER TABLE dbo.GIAI_DAU ADD CONSTRAINT CHK_GD_TRANGTHAI
CHECK (trang_thai IN ('nhap','cho_xet_duyet','chuan_bi_dien_ra','dang_dien_ra','tong_ket','ket_thuc','tam_hoan','khoa'));
GO

IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CHK_TV_VAITRO' AND parent_object_id = OBJECT_ID('dbo.THANH_VIEN_DOI'))
BEGIN
    ALTER TABLE dbo.THANH_VIEN_DOI DROP CONSTRAINT CHK_TV_VAITRO;
END
GO

ALTER TABLE dbo.THANH_VIEN_DOI ADD CONSTRAINT CHK_TV_VAITRO
CHECK (vai_tro_noi_bo IN ('chu_tich', 'thanh_vien', 'ban_dieu_hanh', 'doi_truong'));
GO

-- ============================================================== 
-- SECTION 8 — PLAYER STATS & LEADERBOARD
-- ============================================================== 

-- ---------------------------------------------------------------
-- 8.1  CHI_TIET_NGUOI_CHOI_TRAN  (Per-player stats in a match)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'CHI_TIET_NGUOI_CHOI_TRAN')
BEGIN
    CREATE TABLE CHI_TIET_NGUOI_CHOI_TRAN (
        ma_chi_tiet   INT   IDENTITY PRIMARY KEY,
        ma_tran       INT   NOT NULL,
        ma_nguoi_dung INT   NOT NULL,
        ma_vi_tri     INT   NULL,
        so_kill       INT   NOT NULL CONSTRAINT DF_CTUNCT_KILL   DEFAULT 0,
        so_death      INT   NOT NULL CONSTRAINT DF_CTUNCT_DEATH  DEFAULT 0,
        so_assist     INT   NOT NULL CONSTRAINT DF_CTUNCT_ASSIST DEFAULT 0,
        diem_kda_tran FLOAT NULL,     -- (kill + assist) / MAX(1, death)
        diem_sinh_ton FLOAT NULL,     -- Battle Royale survival score
        is_mvp_tran   BIT   NOT NULL CONSTRAINT DF_CTUNCT_MVP    DEFAULT 0,

        CONSTRAINT FK_CTUNCT_TD    FOREIGN KEY (ma_tran)        REFERENCES TRAN_DAU(ma_tran),
        CONSTRAINT FK_CTUNCT_ND    FOREIGN KEY (ma_nguoi_dung)  REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_CTUNCT_VITRI FOREIGN KEY (ma_vi_tri)      REFERENCES DANH_MUC_VI_TRI(ma_vi_tri)
    );
END
GO

-- ---------------------------------------------------------------
-- 8.2  BANG_XEP_HANG  (Team leaderboard per stage)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'BANG_XEP_HANG')
BEGIN
    CREATE TABLE BANG_XEP_HANG (
        ma_bxh             INT   IDENTITY PRIMARY KEY,
        ma_giai_dau        INT   NOT NULL,
        ma_giai_doan       INT   NULL,
        ma_nhom            INT   NOT NULL,
        so_tran_da_dau     INT   NOT NULL CONSTRAINT DF_BXH_SOTRAN   DEFAULT 0,
        -- MOBA / FPS
        so_tran_thang      INT   NOT NULL CONSTRAINT DF_BXH_THANG    DEFAULT 0,
        so_tran_thua       INT   NOT NULL CONSTRAINT DF_BXH_THUA     DEFAULT 0,
        hieu_so_phu        INT   NOT NULL CONSTRAINT DF_BXH_HIEUSOPP DEFAULT 0,
        -- Battle Royale
        tong_diem_hang     FLOAT NOT NULL CONSTRAINT DF_BXH_DIEMHANG DEFAULT 0,
        tong_diem_kill     FLOAT NOT NULL CONSTRAINT DF_BXH_DIEMKILL DEFAULT 0,
        so_lan_top_1       INT   NOT NULL CONSTRAINT DF_BXH_TOP1     DEFAULT 0,
        -- Summary
        diem_tong_ket      FLOAT NOT NULL CONSTRAINT DF_BXH_TONGKET  DEFAULT 0,
        thu_hang_hien_tai  INT   NOT NULL CONSTRAINT DF_BXH_THURANG  DEFAULT 0,
        is_match_point     BIT   NOT NULL CONSTRAINT DF_BXH_MATCHPOINT DEFAULT 0,

        CONSTRAINT FK_BXH_GD    FOREIGN KEY (ma_giai_dau)  REFERENCES GIAI_DAU(ma_giai_dau),
        CONSTRAINT FK_BXH_GDO   FOREIGN KEY (ma_giai_doan) REFERENCES GIAI_DOAN(ma_giai_doan),
        CONSTRAINT FK_BXH_NHOM  FOREIGN KEY (ma_nhom)      REFERENCES NHOM_DOI(ma_nhom),
        -- One row per squad per stage
        CONSTRAINT UQ_BXH_GIAIDOAN_NHOM UNIQUE (ma_giai_doan, ma_nhom)
    );
END
GO

-- ---------------------------------------------------------------
-- 8.3  BANG_XEP_HANG_CA_NHAN  (Individual leaderboard — MVP)
-- ---------------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'BANG_XEP_HANG_CA_NHAN')
BEGIN
    CREATE TABLE BANG_XEP_HANG_CA_NHAN (
        ma_bxh_cn          INT   IDENTITY PRIMARY KEY,
        ma_giai_dau        INT   NOT NULL,
        ma_nguoi_dung      INT   NOT NULL,
        tong_kill          INT   NOT NULL CONSTRAINT DF_BXHCN_KILL   DEFAULT 0,
        tong_death         INT   NOT NULL CONSTRAINT DF_BXHCN_DEATH  DEFAULT 0,
        tong_assist        INT   NOT NULL CONSTRAINT DF_BXHCN_ASSIST DEFAULT 0,
        diem_kda_trung_binh FLOAT NOT NULL CONSTRAINT DF_BXHCN_KDA  DEFAULT 0,
        so_lan_dat_mvp_tran INT  NOT NULL CONSTRAINT DF_BXHCN_MVP   DEFAULT 0,

        CONSTRAINT FK_BXHCN_GD  FOREIGN KEY (ma_giai_dau)   REFERENCES GIAI_DAU(ma_giai_dau),
        CONSTRAINT FK_BXHCN_ND  FOREIGN KEY (ma_nguoi_dung) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT UQ_BXHCN     UNIQUE (ma_giai_dau, ma_nguoi_dung)
    );
END
GO

-- ==============================================================
-- SECTION 9 — NOTIFICATIONS
-- ==============================================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'THONG_BAO')
BEGIN
    CREATE TABLE THONG_BAO (
        ma_thong_bao  INT           IDENTITY PRIMARY KEY,
        ma_nguoi_nhan INT           NOT NULL,
        tieu_de       NVARCHAR(200) NOT NULL,
        noi_dung      NVARCHAR(MAX) NULL,
        loai_thong_bao NVARCHAR(50) NULL,
        loai_entity   NVARCHAR(50) NULL,     -- 'loi_moi','xin_gia_nhap','giai_dau','doi'
        ma_entity     INT           NULL,    -- FK-free; entity may vary
        hanh_dong     NVARCHAR(50) NULL,     -- 'accept','decline', etc.
        da_doc        BIT           NOT NULL CONSTRAINT DF_TB_DADOC DEFAULT 0,
        ngay_tao      DATETIME      NOT NULL CONSTRAINT DF_TB_NGAYTAO DEFAULT GETDATE(),

        CONSTRAINT FK_TB_ND FOREIGN KEY (ma_nguoi_nhan) REFERENCES NGUOI_DUNG(ma_nguoi_dung)
    );
END
GO

-- ==============================================================
-- SECTION 10 — ENGAGEMENT (Like & Follow)
-- ==============================================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'TUONG_TAC_GIAI_DAU')
BEGIN
    CREATE TABLE TUONG_TAC_GIAI_DAU (
        ma_tuong_tac  INT      IDENTITY PRIMARY KEY,
        ma_nguoi_dung INT      NOT NULL,
        ma_giai_dau   INT      NOT NULL,
        da_like       BIT      NOT NULL CONSTRAINT DF_TTGD_LIKE   DEFAULT 0,
        dang_theo_doi BIT      NOT NULL CONSTRAINT DF_TTGD_FOLLOW DEFAULT 0,
        thoi_gian_tao DATETIME NOT NULL CONSTRAINT DF_TTGD_THOIGIAN DEFAULT GETDATE(),

        CONSTRAINT FK_TTGD_ND  FOREIGN KEY (ma_nguoi_dung) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_TTGD_GD  FOREIGN KEY (ma_giai_dau)   REFERENCES GIAI_DAU(ma_giai_dau),
        CONSTRAINT UQ_TTGD     UNIQUE (ma_nguoi_dung, ma_giai_dau)
    );
END
GO

-- ==============================================================
-- SECTION 11 — VIEWS
-- ==============================================================

-- ---------------------------------------------------------------
-- V1  VW_DASHBOARD_STATS  (Admin global dashboard)
-- ---------------------------------------------------------------
IF OBJECT_ID('VW_DASHBOARD_STATS', 'V') IS NOT NULL
    DROP VIEW VW_DASHBOARD_STATS;
GO
CREATE VIEW VW_DASHBOARD_STATS AS
SELECT
    (SELECT COUNT(1) FROM NGUOI_DUNG     WHERE is_banned   = 0)                                         AS tong_user_active,
    (SELECT COUNT(1) FROM NGUOI_DUNG     WHERE is_banned   = 1)                                         AS tong_user_bi_ban,
    (SELECT COUNT(1) FROM GIAI_DAU       WHERE trang_thai  = 'dang_dien_ra' AND is_deleted = 0)         AS giai_dang_chay,
    (SELECT COUNT(1) FROM GIAI_DAU       WHERE trang_thai IN ('chuan_bi_dien_ra','dang_dien_ra') AND is_deleted = 0) AS giai_dang_hoat_dong,
    (SELECT COUNT(1) FROM DOI            WHERE trang_thai  = 'dang_hoat_dong')                          AS tong_doi_hoat_dong,
    (SELECT COUNT(1) FROM KHIEU_NAI_KET_QUA WHERE trang_thai = 'cho_xu_ly')                            AS khieu_nai_cho_xu_ly,
    (SELECT COUNT(1) FROM GIAI_DAU       WHERE trang_thai  = 'cho_xet_duyet' AND is_deleted = 0)        AS giai_cho_duyet,
    (SELECT COUNT(1) FROM TRO_CHOI       WHERE is_active   = 1)                                         AS tong_game_active;
GO

-- ---------------------------------------------------------------
-- V2  VW_TUONG_TAC_TONG_HOP  (Like / Follow count per tournament)
-- ---------------------------------------------------------------
IF OBJECT_ID('VW_TUONG_TAC_TONG_HOP', 'V') IS NOT NULL
    DROP VIEW VW_TUONG_TAC_TONG_HOP;
GO
CREATE VIEW VW_TUONG_TAC_TONG_HOP AS
SELECT
    ma_giai_dau,
    SUM(CAST(da_like       AS INT)) AS tong_like,
    SUM(CAST(dang_theo_doi AS INT)) AS tong_theo_doi
FROM TUONG_TAC_GIAI_DAU
GROUP BY ma_giai_dau;
GO

-- ==============================================================
-- SECTION 12 — RECOMMENDED INDEXES
-- (Beyond the ones created automatically for PK / UNIQUE)
-- ==============================================================

-- Fast lookup: notifications by recipient + read status
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_TB_NGUOINHAN_DADOC' AND object_id = OBJECT_ID('THONG_BAO'))
BEGIN
    CREATE INDEX IX_TB_NGUOINHAN_DADOC
        ON THONG_BAO(ma_nguoi_nhan, da_doc)
        INCLUDE (tieu_de, ngay_tao);
END

-- Fast lookup: tournaments by status (public listing)
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_GD_TRANGTHAI_PUBLIC' AND object_id = OBJECT_ID('GIAI_DAU'))
BEGIN
    CREATE INDEX IX_GD_TRANGTHAI_PUBLIC
        ON GIAI_DAU(trang_thai, is_deleted, hien_thi_public)
        INCLUDE (ten_giai_dau, ngay_bat_dau, ma_tro_choi);
END

-- Fast lookup: squad members by squad
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_TV_NHOM_TRANGTHAI' AND object_id = OBJECT_ID('THANH_VIEN_DOI'))
BEGIN
    CREATE INDEX IX_TV_NHOM_TRANGTHAI
        ON THANH_VIEN_DOI(ma_nhom, trang_thai_duyet)
        INCLUDE (ma_nguoi_dung, vai_tro_noi_bo);
END

-- Fast lookup: match list per tournament stage
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_TD_GD_GDO_TRANGTHAI' AND object_id = OBJECT_ID('TRAN_DAU'))
BEGIN
    CREATE INDEX IX_TD_GD_GDO_TRANGTHAI
        ON TRAN_DAU(ma_giai_dau, ma_giai_doan, trang_thai)
        INCLUDE (thoi_gian_bat_dau, the_thuc_tran);
END

-- Fast lookup: player stats per match
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CTUNCT_TRAN' AND object_id = OBJECT_ID('CHI_TIET_NGUOI_CHOI_TRAN'))
BEGIN
    CREATE INDEX IX_CTUNCT_TRAN
        ON CHI_TIET_NGUOI_CHOI_TRAN(ma_tran)
        INCLUDE (ma_nguoi_dung, so_kill, so_death, so_assist, is_mvp_tran);
END

-- Fast lookup: individual leaderboard per tournament
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_BXHCN_GD_KDA' AND object_id = OBJECT_ID('BANG_XEP_HANG_CA_NHAN'))
BEGIN
    CREATE INDEX IX_BXHCN_GD_KDA
        ON BANG_XEP_HANG_CA_NHAN(ma_giai_dau, diem_kda_trung_binh DESC)
        INCLUDE (ma_nguoi_dung, so_lan_dat_mvp_tran);
END

GO

-- [Added by Agent] Table for Referee Registration
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'DANG_KY_TRONG_TAI')
BEGIN
    CREATE TABLE DANG_KY_TRONG_TAI (
        ma_dang_ky INT IDENTITY(1,1) PRIMARY KEY,
        ma_nguoi_dung INT NOT NULL,
        ma_tro_choi INT NOT NULL,
        trang_thai NVARCHAR(50) DEFAULT 'cho_duyet',
        ngay_dang_ky DATETIME DEFAULT GETDATE(),
        thoi_gian_duyet DATETIME NULL,
        CONSTRAINT FK_DangKyTrongTai_NguoiDung FOREIGN KEY (ma_nguoi_dung) REFERENCES NGUOI_DUNG(ma_nguoi_dung),
        CONSTRAINT FK_DangKyTrongTai_TroChoi FOREIGN KEY (ma_tro_choi) REFERENCES TRO_CHOI(ma_tro_choi)
    );
END
GO

-- ==============================================================
-- DONE
-- ==============================================================
PRINT N'QuanLy_Esports database initialized successfully.';
GO

